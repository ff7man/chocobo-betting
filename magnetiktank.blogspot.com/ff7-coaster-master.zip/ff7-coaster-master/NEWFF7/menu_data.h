/*
	Final Fantasy VII
	(c) 1997 Square
	decompiled by ergonomy_joe in 2018
*/
#ifndef __MENU_DATA_H__
#define __MENU_DATA_H__

////////////////////////////////////////
extern void C_006C4946(int, int);//set SFX&MIDI volumes?
////////////////////////////////////////

#endif
