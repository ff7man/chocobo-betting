# ff7-worldmap

This Visual Studio 2008 project allows to you to build a standalone version of the FF7 World Map engine. The Graphics/Sound/Menu functions are provided through library files(The Menu library is used for dialog windows).

WorldMapMain.cpp is an original creation(though I used parts of the original "main.c"). It tries to load one of your "save??.ff7" files so you should indicate valid "fileindex" and "saveindex" before building/runing.

The World Map Engine source code have been recreated by decompiling the original FF7 executable file. I should add more comments in the future and rename some of the structures'fields and functions, but for now you can enjoy the algorithms in their splendor ...

by ergonomy_joe
